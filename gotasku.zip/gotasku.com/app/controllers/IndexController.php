<?php

class IndexController extends ControllerBase
{

    public function indexAction()
    {

    }


}

