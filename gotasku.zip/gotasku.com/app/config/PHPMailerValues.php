<?php
/**
 * Created by PhpStorm.
 * User: Satyanarayan
 * Date: 25-04-2015
 * Time: 12:38
 */
//MAIL credentials

define('PHP_MAILER_IS_SMTP',1);
define('PHP_MAILER_CHAR_SET','UTF-8');
define('PHP_MAILER_SMTP_DEBUG',0);
define('PHP_MAILER_SMTP_AUTH',1);
define('PHP_MAILER_SMTP_SECURE','ssl');

define('PHP_MAILER_SMTP_HOST','smtp.gmail.com');
define('PHP_MAILER_PORT',465);
define('PHP_MAILER_USER','satyan.iyengar@gmail.com');
define('PHP_MAILER_PASSWORD','Sat#1302');


define('PHP_MAILER_FROM','satyan.iyengar@gmail.com');
define('PHP_MAILER_SENDER','gotasku');
//define('','');
//define('','');